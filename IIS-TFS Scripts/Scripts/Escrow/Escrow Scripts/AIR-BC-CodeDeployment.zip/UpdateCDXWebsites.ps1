﻿<#
PURPOSE:
Deploy ProdBuild.zip to BC's Web0, and Report1

CREATED:
2014.09.29 - ESH

UPDATED:


#>
# Set variables & constants
$scriptPath = split-path -parent $MyInvocation.MyCommand.Definition
set-alias sz "$scriptPath\7z.exe" 
$scriptName = $MyInvocation.MyCommand.Name
$startTime = Get-Date
$timeDateStamp = $(Get-Date -f yyyy-MM-dd)
$logFile = "$scriptName-$timeDateStamp.log"

$prodBuildZipFile = "ProdBuild.zip"

# BEGIN FUNCTIONS ===========================================
function ShowScriptBegin()
{
	cls
	#SStart-Transcript -path $logFile -append
	"
	Script Start-Time: $startTime
	"
}

function ShowScriptEnd()
{
	$endTime = Get-Date
	$elapsedTime = $endTime - $startTime
	"
	Complete at: $endTime

	Duration:
	{2} hours, {0} minute(s) and {1} second(s)" -f $elapsedTime.Minutes, $elapsedTime.Seconds, $elapsedTime.Hours
	#Stop-Transcript
}

function CreateTempDir
{
   $tmpDir = [System.IO.Path]::GetTempPath()
   $tmpDir = [System.IO.Path]::Combine($tmpDir, [System.IO.Path]::GetRandomFileName())
   [System.IO.Directory]::CreateDirectory($tmpDir) | Out-Null
   $tmpDir
}

function PromoteWebsite
{
	param ($sourceDir, $targetDir)
	
	if(!($sourceDir) -or !($targetDir))
	{
		"Missing Source or Target Directory parameters."
		return
	}	

	$tempDir = CreateTempDir
	$excludeExts = @("sln", "metaproj", "vspscc", "resx", "tmp", "vb", "vbproj", "cs", "csproj", "resx", "pdb", "bak", "user", "suo", "vssscc")
	$excludeDirs = @("obj", "RadControls", "Service References", "Web References", "My Project")

	Write-Host "Source Path: $sourceDir"
	Write-Host "Destination Path: $targetDir"
	Write-Host "Temp Path: $tempDir"
	
	# Verify that target directory exists, if not create it. #>
	if(!(Test-Path $targetDir)){ 
		New-Item -ItemType Directory -Force -Path $targetDir
	}
	
	#Copy source to temp dir...
	Copy-Item $sourceDir\* $tempDir -recurse -force

	# Remove unnecessary files by extension from source.#>
	for ($i=0; $i -lt $excludeDirs.length; $i++) {
		$currentDir = "\" + $excludeDirs[$i]
		$finalDir = $tempDir + $currentDir
		if(Test-Path $finalDir) { Remove-Item -Recurse -Force $finalDir }
	}

	# Remove unnecessary files by extension from source. #>
	for ($i=0; $i -lt $excludeExts.length; $i++) {
		$current = "*." + $excludeExts[$i]
		get-childitem $tempDir -include $current -recurse | foreach ($_) {remove-item $_.fullname -force}
	}

	# Copy files from source to destination (aka: The Beef #>
	Copy-Item $tempDir\* $targetDir -recurse -force	
	
	# Delete the temp directory created...
	Remove-Item -recurse -force $tempDir
}

function FTPDownloadProdBuild()
{
	param ($tempZipDir)
	$tempZipDir
	
	$ftpHost = "ftp.xceligent.com" 
	$user = "Acxiom" 
	$pass = "MoveItNow"
	
	$targetFile = "$tempZipDir\$prodBuildZipFile"
	$ftp = "ftp://{0}:{1}@{2}/{3}" -f $user, $pass, $ftpHost, $prodBuildZipFile
	$ftp
	$webclient = New-Object System.Net.WebClient
	$uri = New-Object System.Uri($ftp)
	"Downloading $targetFile... $targetFile"
	$webclient.DownloadFile($uri, $targetFile)
	
	$targetFile
}

function UnzipRollPackage()
{
	param ($fullPathToZip, $tempDeployDir)
	"Unzipping: $fullPathToZip to $tempDeployDir"
	sz x "-o$tempDeployDir" $fullPathToZip
}

# END FUNCTIONS ===========================================

# BEGIN SCRIPT ===========================================
ShowScriptBegin

#Create Temporary Zip Directory Location
$tempZipDir = CreateTempDir
$tempDeployDir = CreateTempDir

"Temp Zip Dir: $tempZipDir"
"Temp Deploy Dir: $tempDeployDir"

#Download BuildProd.zip from ftp.xceligent.com
$fullPathToZip = FTPDownloadProdBuild $tempZipDir

#Extract to Temporary Directory
UnzipRollPackage $fullPathToZip $tempDeployDir

#Promote CDX, and all others
$sourceDir = "$tempDeployDir\ProdBuild\Production"
$targetDir = "\\web0\d$\Inetpub\Production"
PromoteWebsite $sourceDir $targetDir



#Remove Temporary Directory

ShowScriptEnd

# END SCRIPT ===========================================


