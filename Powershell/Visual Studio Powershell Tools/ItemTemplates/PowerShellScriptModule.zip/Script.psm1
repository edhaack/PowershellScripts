<# 
 .Synopsis

 .Description

 .Parameter 

 .Example
 
#>
#$publicVariable = 'publicValue'

function $safeitemname$ {
	
}

#Export-ModuleMember -Variable $publicVariable
Export-ModuleMember -Function $safeitemname$