<# 
 .Synopsis
  <Description>

 .Description
  <Description>
  
 .Author
	- $username$
	- $time$

 .Parameter <name>
  <Description>

 .Example
  <Description>
    $safeitemname$

#>
function $safeitemname$ {

}
export-modulemember -function $safeitemname$